import "./App.css";
import Swiper_01 from "./components/Swiper_01";

function App() {
  return (
    <>
      <Swiper_01 />
    </>
  );
}

export default App;
